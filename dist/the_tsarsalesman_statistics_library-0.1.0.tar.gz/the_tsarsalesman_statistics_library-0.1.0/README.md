# tsarsalesman's Statistics Package

A lite-weight solution to statistical needs!
